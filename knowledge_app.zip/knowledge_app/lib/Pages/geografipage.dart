import 'package:flutter/material.dart';
import '../widgets/geografi_card.dart';

class GeografiPage extends StatelessWidget {
  const GeografiPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F6FC),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Header
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF36D1DC), Color(0xFF5B86E5)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(20),
                    bottomRight: Radius.circular(20),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: () => Navigator.pop(context),
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'Dunia Geografi 🌍',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Pelajari bentuk muka bumi dan fenomena geografis lainnya!',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),

              // Konten
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SectionTitle(title: 'Bentang Alam 🏞️'),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: GeografiCard(
                            emoji: '⛰️',
                            title: 'Pegunungan',
                            description: 'Pegunungan adalah bagian tinggi dari permukaan bumi...',
                            onTap: () {},
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: GeografiCard(
                            emoji: '🏝️',
                            title: 'Pulau',
                            description: 'Pulau adalah daratan yang dikelilingi air...',
                            onTap: () {},
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    const SectionTitle(title: 'Fenomena Alam 🌪️'),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: GeografiCard(
                            emoji: '🌋',
                            title: 'Gunung Api',
                            description: 'Gunung berapi dapat meletus dan mengeluarkan magma...',
                            onTap: () {},
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: GeografiCard(
                            emoji: '🌊',
                            title: 'Tsunami',
                            description: 'Gelombang laut besar akibat aktivitas seismik...',
                            onTap: () {},
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.black87,
      ),
    );
  }
}
