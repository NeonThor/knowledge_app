import 'package:flutter/material.dart';
import '../widgets/animal_card.dart';

class HewanPage extends StatelessWidget {
  const HewanPage({super.key});

  void showDetail(BuildContext context, String route) {
    Navigator.pushNamed(context, route);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F6FC),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF6FCF97), Color(0xFF56CCF2)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(20),
                    bottomRight: Radius.circular(20),
                  ),
                ),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'Dunia Hewan ',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SectionTitle(title: 'Mamalia 🐘'),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: AnimalCard(
                            emoji: '🐘',
                            title: 'Gajah',
                            description: 'Mamalia terbesar di darat yang cerdas dan sosial...',
                            onTap: () => showDetail(context, '/gajah'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: AnimalCard(
                            emoji: '🦁',
                            title: 'Singa',
                            description: 'Dikenal sebagai raja hutan dan hidup di padang rumput...',
                            onTap: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Detail tentang Singa belum tersedia.')),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    const SectionTitle(title: 'Burung 🐦'),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: AnimalCard(
                            emoji: '🦜',
                            title: 'Burung Kakak Tua',
                            description: 'Burung pintar yang bisa meniru suara manusia...',
                            onTap: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Detail tentang Burung Kakak Tua belum tersedia.')),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: AnimalCard(
                            emoji: '🦉',
                            title: 'Burung Hantu',
                            description: 'Burung malam dengan penglihatan tajam...',
                            onTap: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Detail tentang Burung Hantu belum tersedia.')),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.black87,
      ),
    );
  }
}
