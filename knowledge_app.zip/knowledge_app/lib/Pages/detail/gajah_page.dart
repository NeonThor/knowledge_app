import 'package:flutter/material.dart';

class GajahPage extends StatelessWidget {
  const GajahPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFF6FF),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header with back button
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF6FCF97), Color(0xFF56CCF2)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    '🐘 Mari Belajar Tentang Gajah!',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Hewan terbesar di darat yang super keren!',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Apa itu Gajah?
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.green.shade200),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 4,
                      offset: Offset(0, 2),
                    )
                  ],
                ),
                child: Column(
                  children: const [
                    Text(
                      '✨ Apa itu Gajah? ✨',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Gajah adalah hewan darat TERBESAR di dunia! Mereka sangat pintar, punya ingatan '
                      'yang luar biasa, dan hidup berkelompok seperti keluarga besar. Gajah punya belalai '
                      'panjang yang bisa digunakan untuk banyak hal seru!',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            // 3 Cards Horizontal
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: const [
                  Expanded(
                    child: InfoCard(
                      color: Colors.pinkAccent,
                      title: 'Super Pintar!',
                      text:
                          'Gajah bisa mengenali dirinya di cermin! Mereka juga bisa mengingat teman-temannya bertahun-tahun.',
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: InfoCard(
                      color: Colors.blueAccent,
                      title: 'Keluarga Besar',
                      text:
                          'Gajah hidup dalam kelompok yang dipimpin oleh gajah betina tertua.',
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: InfoCard(
                      color: Colors.purpleAccent,
                      title: 'Belalai Ajaib',
                      text:
                          'Belalai gajah punya 40.000 otot! Bisa untuk minum, memeluk, dan makan.',
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Habitat
            const SectionBox(
              title: '🌿 Dimana Gajah Tinggal?',
              content:
                  'Gajah tinggal di hutan tropis, padang rumput, dan sabana. Mereka suka tempat yang ada banyak air dan makanan!',
              icons: ['🌳', '🌾', '💧'],
              imageAsset: 'assets/images/gajah1.jpeg',
            ),

            const SizedBox(height: 24),

            // Makanan
            const SectionBox(
              title: '🥬 Apa yang Dimakan Gajah?',
              content:
                  'Gajah adalah hewan vegetarian! Mereka makan rumput, daun, buah-buahan, dan kulit pohon. Gajah dewasa bisa makan sampai **150 kg** makanan setiap hari!',
              icons: ['🌿', '🍃', '🍌', '🌳'],
              imageAsset: 'assets/images/rumput.jpg',
            ),

            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

class InfoCard extends StatelessWidget {
  final Color color;
  final String title;
  final String text;

  const InfoCard({
    super.key,
    required this.color,
    required this.title,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: color.withOpacity(0.2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text(
              title,
              style: TextStyle(
                  fontWeight: FontWeight.bold, color: color, fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(text, style: const TextStyle(fontSize: 14)),
          ],
        ),
      ),
    );
  }
}

class SectionBox extends StatelessWidget {
  final String title;
  final String content;
  final List<String> icons;
  final String? imageAsset;

  const SectionBox({
    super.key,
    required this.title,
    required this.content,
    required this.icons,
    this.imageAsset,
  });

  @override
  Widget build(BuildContext context) {
    List<InlineSpan> parseText(String text) {
      final parts = text.split(RegExp(r'(\*\*.*?\*\*)'));
      return parts.map((part) {
        if (part.startsWith('**') && part.endsWith('**')) {
          return TextSpan(
            text: part.replaceAll('**', ''),
            style: const TextStyle(fontWeight: FontWeight.bold),
          );
        } else {
          return TextSpan(text: part);
        }
      }).toList();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.green.shade50,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                )),
            const SizedBox(height: 8),
            RichText(
              text: TextSpan(
                style: const TextStyle(fontSize: 14, color: Colors.black),
                children: parseText(content),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: icons
                  .map((icon) => Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: Text(icon, style: const TextStyle(fontSize: 24)),
                      ))
                  .toList(),
            ),
            if (imageAsset != null) ...[
              const SizedBox(height: 16),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(imageAsset!, height: 150, fit: BoxFit.cover),
              ),
            ]
          ],
        ),
      ),
    );
  }
}
