import 'package:flutter/material.dart';


class TumbuhanPage extends StatelessWidget {
  const TumbuhanPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F6FC), // sama seperti Home
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Header Gradient ala Home
// Ganti bagian dalam Container (header) menjadi ini:
Container(
  width: double.infinity,
  padding: const EdgeInsets.all(20),
  decoration: const BoxDecoration(
    gradient: LinearGradient(
      colors: [Color(0xFFFB7BA2), Color(0xFFFCE043)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
    borderRadius: BorderRadius.only(
      bottomLeft: Radius.circular(20),
      bottomRight: Radius.circular(20),
    ),
  ),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(width: 8),
          const Text(
            'Dunia Tanaman 🌱',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ],
      ),
      const SizedBox(height: 8),
      const Text(
        'Jelajahi keajaiban dunia tumbuhan yang hijau dan segar!',
        style: TextStyle(
          fontSize: 14,
          color: Colors.white70,
        ),
      ),
    ],
  ),
),

              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SectionTitle(title: 'Bunga 🌸'),
                    const SizedBox(height: 10),
                    Row(
                      children: const [
                        Expanded(
                          child: PlantCard(
                            emoji: '🌻',
                            title: 'Bunga Matahari',
                            description: 'Bunga matahari adalah bunga besar berwarna kuning cerah...',
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: PlantCard(
                            emoji: '🌹',
                            title: 'Mawar',
                            description: 'Mawar adalah bunga cantik dan harum. Tersedia dalam berbagai warna...',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    const SectionTitle(title: 'Pohon 🌳'),
                    const SizedBox(height: 10),
                    Row(
                      children: const [
                        Expanded(
                          child: PlantCard(
                            emoji: '🥭',
                            title: 'Pohon Mangga',
                            description: 'Pohon yang menghasilkan buah mangga manis dan segar...',
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: PlantCard(
                            emoji: '🍎',
                            title: 'Pohon Apel',
                            description: 'Pohon buah populer dengan buah apel merah atau hijau...',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.black87,
      ),
    );
  }
}

class PlantCard extends StatelessWidget {
  final String emoji;
  final String title;
  final String description;

  const PlantCard({super.key, 
    required this.emoji,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(
          colors: [Color(0xFFFB7BA2), Color(0xFFFCE043)], // gradasi pink ke kuning seperti Home
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            emoji,
            style: const TextStyle(fontSize: 32),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            description,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 14,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white24,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            onPressed: () {},
            child: const Text('Pelajari lebih lanjut! ➡'),
          ),
        ],
      ),
    );
  }
}
