import 'package:flutter/material.dart';
import 'package:knowledge_app/Pages/geografipage.dart';
import 'package:knowledge_app/Pages/gunungpage.dart';
import 'package:knowledge_app/Pages/hewanpage.dart';
import 'package:knowledge_app/Pages/tumbuhanpage.dart';
import 'dart:async';
import '../widgets/category_card.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Map<String, dynamic>> categories = [
    {'icon': Icons.pets, 'label': 'Hewan'},
    {'icon': Icons.local_florist, 'label': 'Tumbuhan'},
    {'icon': Icons.landscape, 'label': 'Gunung'},
    {'icon': Icons.public, 'label': 'Geografi'},
  ];

  List<List<Color>> gradients = [
    [Colors.green.shade200, Colors.green.shade400],
    [Colors.lightGreen.shade200, Colors.teal.shade300],
    [Colors.greenAccent, Colors.lightBlueAccent],
  ];

  int _gradientIndex = 0;
  Timer? _timer; // Add this line

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(Duration(seconds: 3), (timer) {
      if (!mounted) return; // Ensure widget is still in the tree
      setState(() {
        _gradientIndex = (_gradientIndex + 1) % gradients.length;
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel(); // Cancel the timer to avoid calling setState after dispose
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          // Animated Gradient Header
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: AnimatedContainer(
              duration: Duration(seconds: 2),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: gradients[_gradientIndex],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.green.withOpacity(0.3),
                    blurRadius: 8,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundImage: AssetImage('assets/profile.jpg'),
                    radius: 28,
                  ),
                  SizedBox(width: 16),
                  Text(
                    'Halo, Budi!',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      shadows: [
                        Shadow(
                          offset: Offset(1, 1),
                          blurRadius: 2,
                          color: Colors.black26,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Grid Kategori
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: GridView.builder(
                itemCount: categories.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 16,
                  crossAxisSpacing: 16,
                ),
                itemBuilder: (context, index) {
                  final category = categories[index];
                  return CategoryCard(
                    icon: category['icon'],
                    label: category['label'],
                    onTap: () {
                      switch (category['label']) {
                        case 'Hewan':
                          Navigator.push(context, MaterialPageRoute(builder: (_) => HewanPage()));
                          break;
                        case 'Tumbuhan':
                          Navigator.push(context, MaterialPageRoute(builder: (_) => TumbuhanPage()));
                          break;
                        case 'Gunung':
                          Navigator.push(context, MaterialPageRoute(builder: (_) => GunungPage()));
                          break;
                        case 'Geografi':
                          Navigator.push(context, MaterialPageRoute(builder: (_) => GeografiPage()));
                          break;
                      }
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
